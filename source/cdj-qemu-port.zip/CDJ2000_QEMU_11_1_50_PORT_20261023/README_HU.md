# CDJ-2000 emulátor – QEMU 11.1.50 kompatibilitási csomag (2026.10.23.)

Ez **QEMU-forráskód javítása**, NEM Pioneer firmware és NEM telepíthető .UPD.

A user által feltöltött `qemu-master.zip` QEMU VERSION=11.1.50, a CDJ emulátor patch-készlete ehhez néhány helyen nem illeszkedett. A teljes QEMU SH-4/CDJ hardvermodell átemelését, C66x DSP-kódját és a négy SH-4 fordítópatch kompatibilitási átírását ez a delta tartalmazza.

- Forrás: QEMU `qemu-master.zip` + `cdj2000-emulator-main.zip` (a felhasználó által feltöltve)
- A patch **forrásfájlokra** vonatkozik, gyári firmware-t nem tartalmaz.
- A forrásösszeállítás ellenőrizve; a működő SH-4 bináris fordítása **NEM sikerült** ebben a környezetben.
- Pontos ok: hiányoznak a fejlesztői GLib/Pixman csomagok; a QEMU konfigurálás közben további Python-csomagokat (pl. `qemu.qmp`) akar letölteni, de a hálózati elérés le van tiltva.
- A patch alkalmazhatóságát tiszta eredeti QEMU forráson teszteljük a csomag előállításakor.

## Használat fejlesztői gépen (Linux)

A QEMU eredeti zipjét csomagold ki (`qemu-master` könyvtár), majd a szükséges fordítók és függőségek telepítése után:

```bash
sh apply_and_build.sh /abszolut/utvonal/qemu-master
```

Példa Debian fejlesztői csomagok: `build-essential`, `python3`, `python3-pip`, `ninja-build`, `pkg-config`, `libglib2.0-dev`, `libpixman-1-dev`, `libglib2.0-dev` (a GModule-t is biztosítja), Meson. A konfiguráció kérhet további csomagokat.

**Biztonság:** a valódi CDJ-2000-re semmilyen módosított firmware-t ne tölts fel csak ettől a forráscsomagtól. A kétprocesszoros boot, lejátszás, SYNC és MASTER ellenőrzése még nem történt meg.

## Az itt elvégzett ellenőrzések

- 138 javított/új forrásfájl, külön ZIP-ellenőrzéssel és SHA-256-tal
- A delta teljes egészében alkalmazható az eredeti QEMU 11.1.50 fájljaira (`patch -p1`), és 138/138 SHA ellenőrzés sikeres.
- A CDJ emulátor 5 forrás/firmware-tesztje sikeres, 15 emulátort igénylő tesztet kihagytunk, mert még nincs lefordított SH-4 futtató.
- A gombkezelő és QEMU integrációs élő tesztjei **nem futottak le**: `pkg-config` nem találja a GLib fejlesztői fájlokat.
- A QEMU konfiguráló elindult, de Python függőséget (`qemu.qmp`) sem tudott internet nélkül telepíteni.
- Nem bizonyított: boot 64 MB RAM-mal, Nexus DSP, SYNC, MASTER, jog, waveform, valódi hardverfrissítés.

**Ez a fejlesztői csomag kizárólag forrásjavítás; a CDJ hardverfrissítője (.UPD) nincs benne.**
