import sys,json,hashlib
from pathlib import Path
q=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
checks=[x for x in m['changed_files'] if x[1]=='new']
conflicts=[x[0] for x in checks if (q/x[0]).exists()]
if conflicts:raise SystemExit('Not a clean QEMU tree; already-patched files: '+str(conflicts[:5]))
print('New-file conflicts: 0; relying on patch hunks to check existing files')
