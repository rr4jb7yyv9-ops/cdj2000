import sys,json,hashlib
from pathlib import Path
root=Path(sys.argv[1]); meta=json.loads(Path(sys.argv[2]).read_text());bad=[]
for name,status,size,sha in meta['changed_files']:
 f=root/name
 if not f.is_file() or len(b:=f.read_bytes())!=size or hashlib.sha256(b).hexdigest()!=sha:bad.append(name)
print('Patched files SHA-256 verified:',len(meta['changed_files'])-len(bad),'/',len(meta['changed_files']))
if bad:raise SystemExit('Bad files: '+str(bad[:12]))
