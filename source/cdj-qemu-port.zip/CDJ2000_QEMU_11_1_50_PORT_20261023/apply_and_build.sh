#!/bin/sh
set -eu
if [ "$#" -ne 1 ]; then echo "Használat: sh apply_and_build.sh /path/to/qemu-master"; exit 2; fi
QEMU=$(cd "$1" && pwd)
SCRIPT=$(cd "$(dirname "$0")" && pwd)
if [ ! -f "$QEMU/VERSION" ] || [ "$(cat "$QEMU/VERSION")" != '11.1.50' ]; then
  echo "Ez a patch csak QEMU VERSION=11.1.50-hez készült" >&2; exit 3
fi
# Avoid partial application on a changed QEMU tree.
python3 "$SCRIPT/check_clean_inputs.py" "$QEMU" "$SCRIPT/source_files.json"
mkdir -p "$QEMU/hw/sh4/c6x/binutils" "$QEMU/include/exec"
patch -d "$QEMU" -p1 --forward --batch < "$SCRIPT/qemu-cdj2000-11.1.50.patch"
python3 "$SCRIPT/check_patched.py" "$QEMU" "$SCRIPT/source_files.json"
chmod +x "$QEMU/configure"
cd "$QEMU"
mkdir -p build
cd build
../configure --target-list=sh4-softmmu --disable-gtk --disable-sdl --disable-vnc --disable-spice --disable-docs --disable-guest-agent --disable-tools --disable-fdt --disable-werror
ninja qemu-system-sh4
./qemu-system-sh4 -M help | grep -i cdj
